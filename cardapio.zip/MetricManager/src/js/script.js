// Dados dos produtos
const products = [
    // PIZZAS
    { id: 1, name: 'Pizza Margherita', price: 45.00, category: 'pizzas', description: 'Tomate, mussarela e manjericão', image: 'https://via.placeholder.com/300x200?text=Margherita' },
    { id: 2, name: 'Pizza Pepperoni', price: 48.00, category: 'pizzas', description: 'Molho, queijo e pepperoni', image: 'https://via.placeholder.com/300x200?text=Pepperoni' },
    { id: 3, name: 'Pizza Frango com Catupiry', price: 50.00, category: 'pizzas', description: 'Frango desfiado e catupiry cremoso', image: 'https://via.placeholder.com/300x200?text=Frango' },
    { id: 4, name: 'Pizza Quatro Queijos', price: 52.00, category: 'pizzas', description: 'Mussarela, gorgonzola, provolone e parmesão', image: 'https://via.placeholder.com/300x200?text=4Queijos' },
    
    // HAMBÚRGUERES
    { id: 5, name: 'Hambúrguer Clássico', price: 35.00, category: 'hamburgueres', description: 'Carne, queijo, alface e tomate', image: 'https://via.placeholder.com/300x200?text=Classico' },
    { id: 6, name: 'Hambúrguer Duplo', price: 42.00, category: 'hamburgueres', description: 'Duas carnes e queijo', image: 'https://via.placeholder.com/300x200?text=Duplo' },
    { id: 7, name: 'Hambúrguer Especial', price: 45.00, category: 'hamburgueres', description: 'Carne, bacon, ovo e molho especial', image: 'https://via.placeholder.com/300x200?text=Especial' },
    
    // BEBIDAS
    { id: 8, name: 'Refrigerante 2L', price: 10.00, category: 'bebidas', description: 'Refrigerante gelado', image: 'https://via.placeholder.com/300x200?text=Refrigerante' },
    { id: 9, name: 'Suco Natural', price: 8.00, category: 'bebidas', description: 'Suco fresco de fruta', image: 'https://via.placeholder.com/300x200?text=Suco' },
    { id: 10, name: 'Cerveja Artesanal', price: 12.00, category: 'bebidas', description: 'Cerveja artesanal 600ml', image: 'https://via.placeholder.com/300x200?text=Cerveja' },
    
    // COMBOS
    { id: 11, name: 'Combo Pizza + Refrigerante', price: 55.00, category: 'combos', description: 'Pizza média + refrigerante 2L', image: 'https://via.placeholder.com/300x200?text=Combo1' },
    { id: 12, name: 'Combo Hambúrguer + Bebida', price: 45.00, category: 'combos', description: 'Hambúrguer + bebida à escolha', image: 'https://via.placeholder.com/300x200?text=Combo2' },
    { id: 13, name: 'Combo Completo', price: 80.00, category: 'combos', description: '2 pizzas médias + refrigerante + sobremesa', image: 'https://via.placeholder.com/300x200?text=Combo3' },
];

// Carrinho
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Atualizar contador do carrinho
function updateCartCount() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelectorAll('.cart-count').forEach(el => el.textContent = count);
}

// Renderizar menu
function renderMenu(filterCategory = 'todos') {
    const menuGrid = document.getElementById('menuGrid');
    if (!menuGrid) return;

    console.log('🔍 renderMenu chamado com categoria:', filterCategory);
    
    // Filtrar produtos
    let filtered;
    if (filterCategory === 'todos' || !filterCategory) {
        filtered = products;
    } else {
        filtered = products.filter(p => p.category.toLowerCase() === filterCategory.toLowerCase());
    }

    console.log('📊 Produtos filtrados:', filtered.length, filtered.map(p => p.name));

    menuGrid.innerHTML = filtered.map(product => `
        <div class="menu-item" data-category="${product.category}">
            <div class="menu-item-img">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="menu-item-content">
                <h3>${product.name}</h3>
                <p class="menu-item-description">${product.description}</p>
                <div class="menu-item-footer">
                    <span class="menu-item-price">R$ ${product.price.toFixed(2)}</span>
                    <div class="menu-item-qty">
                        <input type="number" value="1" min="1" class="qty-input" data-id="${product.id}">
                        <button class="btn btn-sm btn-primary" onclick="addToCart(${product.id})">+</button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

// Adicionar ao carrinho
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const qtyInput = document.querySelector(`input[data-id="${productId}"]`);
    const quantity = parseInt(qtyInput?.value) || 1;

    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({ ...product, quantity });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    
    alert(`✅ ${product.name} adicionado ao carrinho!`);
    if (qtyInput) qtyInput.value = 1;
}

// Remover do carrinho
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    renderCheckout();
}

// Renderizar checkout
function renderCheckout() {
    const cartItems = document.getElementById('cartItems');
    if (!cartItems) return;

    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <p>Seu carrinho está vazio!</p>
                <p>Volte ao <a href="cardapio.html">cardápio</a> para adicionar produtos.</p>
            </div>
        `;
        updateTotal();
        return;
    }

    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p class="cart-item-price">R$ ${item.price.toFixed(2)} x ${item.quantity}</p>
            </div>
            <div class="cart-item-actions">
                <span style="font-weight: 700;">R$ ${(item.price * item.quantity).toFixed(2)}</span>
                <button class="remove-btn" onclick="removeFromCart(${item.id})">Remover</button>
            </div>
        </div>
    `).join('');

    updateTotal();
}

// Atualizar total
function updateTotal() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const delivery = document.querySelector('input[name="delivery"]:checked')?.value === 'retirada' ? 0 : 5;
    const total = subtotal + delivery;

    document.getElementById('subtotal').textContent = `R$ ${subtotal.toFixed(2)}`;
    document.getElementById('delivery').textContent = delivery === 0 ? 'R$ 0,00 (Retirada)' : `R$ ${delivery.toFixed(2)}`;
    document.getElementById('total').textContent = `R$ ${total.toFixed(2)}`;
}

// Variável global para armazenar método de pagamento
let selectedPaymentMethod = null;

// Trocar método de pagamento
function switchPaymentMethod(method) {
    // Remover método anterior
    document.querySelectorAll('.payment-method').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.payment-btn').forEach(btn => btn.classList.remove('active'));
    
    // Mostrar novo método
    selectedPaymentMethod = method;
    document.getElementById(method + 'Method').style.display = 'block';
    document.querySelector(`[data-payment="${method}"]`).classList.add('active');
}

// Confirmar pagamento
function confirmPayment(method) {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const delivery = document.querySelector('input[name="delivery"]:checked')?.value === 'retirada' ? 0 : 5;
    const total = subtotal + delivery;
    const deliveryType = delivery === 0 ? 'Retirada no local' : 'Entrega (R$ 5,00)';
    const paymentMethod = method === 'pix' ? '📱 PIX' : method === 'credito' ? '💳 Cartão de Crédito' : '💳 Cartão de Débito';

    let message = '*📱 Novo Pedido - Seu Restaurante*\n\n';
    message += '*Itens do Pedido:*\n';
    cart.forEach(item => {
        message += `• ${item.name} x${item.quantity} - R$ ${(item.price * item.quantity).toFixed(2)}\n`;
    });
    message += `\n*Modo de Entrega:* ${deliveryType}`;
    message += `\n*Forma de Pagamento:* ${paymentMethod}`;
    message += `\n*Subtotal:* R$ ${subtotal.toFixed(2)}`;
    message += `\n*Total:* R$ ${total.toFixed(2)}`;
    message += `\n\n✅ Pagamento confirmado!`;

    const phone = '5599999999999';
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
    alert('✅ Pagamento confirmado! Redirecionando para o WhatsApp...');
    localStorage.removeItem('cart');
    cart = [];
    updateCartCount();
    setTimeout(() => window.location.href = 'index.html', 2000);
}

// Finalizar pedido (antes era direto, agora mostra opções de pagamento)
function finalizeOrder() {
    if (cart.length === 0) {
        alert('Seu carrinho está vazio!');
        return;
    }

    if (!selectedPaymentMethod) {
        alert('Selecione uma forma de pagamento!');
        return;
    }

    confirmPayment(selectedPaymentMethod);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();

    // Renderizar menu se estiver na página
    const menuGrid = document.getElementById('menuGrid');
    if (menuGrid) {
        // Obter parâmetro da URL
        const params = new URLSearchParams(window.location.search);
        const categoryFromUrl = params.get('cat') || 'todos';
        
        console.log('📍 URL atual:', window.location.href);
        console.log('🏷️ Categoria da URL:', categoryFromUrl);
        
        // Renderizar menu com a categoria
        renderMenu(categoryFromUrl);
        
        // Ativar o botão correto
        document.querySelectorAll('.filter-btn').forEach(btn => {
            if (btn.dataset.filter === categoryFromUrl) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    // Filtros no cardápio - click listener
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            renderMenu(e.target.dataset.filter);
        });
    });

    // Renderizar checkout se estiver na página
    if (document.getElementById('cartItems')) {
        renderCheckout();
    }

    // Atualizar total quando mudar forma de entrega
    document.querySelectorAll('input[name="delivery"]').forEach(input => {
        input.addEventListener('change', updateTotal);
    });

    // Botão finalizar pedido
    const finalizeBtn = document.getElementById('finalizeBtn');
    if (finalizeBtn) {
        finalizeBtn.addEventListener('click', finalizeOrder);
    }

    // Botões de método de pagamento
    document.querySelectorAll('.payment-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            switchPaymentMethod(btn.dataset.payment);
        });
    });

    // Gerar QR Code dinâmico para PIX (usando API de QR code)
    const qrcodeImg = document.getElementById('qrcodeImg');
    if (qrcodeImg) {
        const pixKey = '11999999999'; // Número ou chave PIX
        const qrcodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(pixKey)}`;
        qrcodeImg.src = qrcodeUrl;
    }

    // Formatador de cartão de crédito
    const cardInputs = document.querySelectorAll('.card-form input');
    cardInputs.forEach(input => {
        if (input.placeholder.includes('Cartão')) {
            input.addEventListener('input', function(e) {
                // Formatar como 1234 5678 9012 3456
                let value = e.target.value.replace(/\s/g, '');
                let formatted = value.match(/.{1,4}/g)?.join(' ') || value;
                e.target.value = formatted;
            });
        }
        if (input.placeholder.includes('MM/AA')) {
            input.addEventListener('input', function(e) {
                // Formatar como MM/AA
                let value = e.target.value.replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.slice(0, 2) + '/' + value.slice(2, 4);
                }
                e.target.value = value;
            });
        }
    });
});
