# Cardápio Digital Responsivo com Sistema de Pedidos

## Visão Geral
Plataforma de cardápio digital moderna e responsiva para restaurantes, pizzarias, hamburguerias e serviços de entrega. Os usuários podem visualizar produtos por categorias, adicionar ao carrinho e finalizar pedidos diretamente pelo WhatsApp.

## Estrutura do Projeto
```
/
├── index.html          # Página inicial (Home)
├── cardapio.html       # Página com cardápio e filtros
├── checkout.html       # Página do carrinho e finalizações
├── src/
│   ├── css/
│   │   └── style.css   # Estilos responsivos
│   └── js/
│       └── script.js   # Funcionalidades do carrinho e WhatsApp
├── images/             # Pasta para imagens de produtos
├── .gitignore          # Configuração Git
└── replit.md          # Este arquivo
```

## Características Principais

### 🏠 Página Inicial (Home)
- Banner herói com call-to-action
- Exibição de categorias principais
- Seção de diferenciais do restaurante
- Links rápidos para cardápio

### 🍕 Página de Cardápio
- Grid responsivo de produtos
- Filtros por categorias: Pizzas, Hambúrgueres, Bebidas, Combos
- Adição de quantidade customizável
- Botão "Adicionar ao Carrinho" para cada item
- Imagens e descrições detalhadas

### 🛒 Página de Checkout
- Visualização completa do carrinho
- Listagem de itens com quantidades
- Opções de entrega ou retirada
- Cálculo automático de total
- Integração direta com WhatsApp

## Funcionalidades Implementadas

✅ **Navegação responsiva** - Menu sticky na parte superior
✅ **Sistema de carrinho** - Salvo no localStorage
✅ **Filtros de categorias** - Visualização por tipo de produto
✅ **Contador de carrinho** - Atualização em tempo real
✅ **Cálculo de totais** - Subtotal, taxa, total
✅ **Integração WhatsApp** - Envio automático de mensagens
✅ **Design moderno** - Cores atrativas, animações leves
✅ **Completamente responsivo** - Mobile, tablet e desktop
✅ **Sem dependências** - HTML5, CSS3, JavaScript vanilla

## Produtos Inclusos (13 itens de exemplo)

### 🍕 Pizzas (4 produtos)
- Pizza Margherita - R$ 45,00
- Pizza Pepperoni - R$ 48,00
- Pizza Frango com Catupiry - R$ 50,00
- Pizza Quatro Queijos - R$ 52,00

### 🍔 Hambúrgueres (3 produtos)
- Hambúrguer Clássico - R$ 35,00
- Hambúrguer Duplo - R$ 42,00
- Hambúrguer Especial - R$ 45,00

### 🥤 Bebidas (3 produtos)
- Refrigerante 2L - R$ 10,00
- Suco Natural - R$ 8,00
- Cerveja Artesanal - R$ 12,00

### 🎁 Combos (3 produtos)
- Combo Pizza + Refrigerante - R$ 55,00
- Combo Hambúrguer + Bebida - R$ 45,00
- Combo Completo - R$ 80,00

## Tecnologias Utilizadas
- **HTML5** - Estrutura semântica
- **CSS3** - Layout Flexbox/Grid, animações, responsividade
- **JavaScript Vanilla** - Sem frameworks, código puro
- **Google Fonts (Poppins)** - Tipografia moderna
- **Placeholder images** - Imagens via URL (sem storage local)

## Como Executar
O site é servido via Python HTTP Server na porta 5000:
```bash
python -m http.server 5000
```

Acesse em: `http://localhost:5000`

## Funcionalidades JavaScript Principais

### Carrinho de Compras
- **addToCart()** - Adiciona produtos ao carrinho
- **removeFromCart()** - Remove itens
- **updateCartCount()** - Atualiza contador em tempo real
- **localStorage** - Persiste dados do carrinho

### Renderização Dinâmica
- **renderMenu()** - Exibe produtos com filtros
- **renderCheckout()** - Mostra itens do carrinho
- **updateTotal()** - Calcula valores totais

### Integração WhatsApp
- **finalizeOrder()** - Formata mensagem com pedido
- Link automático: `wa.me/{phone}?text={message}`
- Mensagem estruturada com itens e preços

## Paleta de Cores
- **Primária:** #FF6B35 (Laranja vibrante - CTA)
- **Secundária:** #004E89 (Azul profundo - Links/hover)
- **Destaque:** #FFC300 (Amarelo - Badges/contador)
- **Neutras:** #f8f9fa (Light) e #333 (Dark)

## Customização

### Alterar cardápio
Edite o array `products` em `src/js/script.js`

### Mudar WhatsApp
Procure por `5599999999999` nos arquivos HTML e atualize com seu número

### Adicionar imagens
Coloque arquivos na pasta `images/` e atualize o caminho em `src/js/script.js`

### Personalizar cores
Edite as variáveis CSS em `src/css/style.css` (seção `:root`)

## Requisitos de Performance
- ⚡ Carregamento rápido (< 1s)
- 📱 100% responsivo
- 🎯 Acessibilidade básica
- ♿ Compatibilidade cross-browser
- 🔄 Suporte offline (localStorage)

## Próximas Melhorias Sugeridas
- [ ] Temas claro/escuro
- [ ] Zoom em imagens (lightbox)
- [ ] Sistema de avaliações ⭐
- [ ] Busca de produtos
- [ ] Autenticação de usuário
- [ ] Histórico de pedidos
- [ ] Cupons de desconto

## Data de Criação
24 de Novembro de 2025

## Última Atualização
24 de Novembro de 2025 - Projeto completo criado

## Observações Técnicas
- Site totalmente estático (funciona offline)
- Sem API backend necessária
- localStorage para persistência de carrinho
- Código comentado em português
- Mobile-first approach
- Sem bibliotecas externas (vanilla JS)
